# PULSE Platform v1

Runnable Telegram-first MVP: FastAPI core, Telegram bot, responsive bilingual dashboard, Telegram Mini App signature validation, SQLAlchemy persistence and eBay Browse API adapter.

## Implemented
- Shared backend for Telegram bot and visual web interface.
- Bot commands: `/start`, `/search`, `/watch`, `/my`, `/language`, `/help`.
- English and Spanish strings.
- Telegram Mini App `initData` HMAC and freshness validation.
- eBay OAuth client-credentials + Browse API search.
- User, saved-search and opportunity persistence.
- SQLite locally; PostgreSQL supported through `DATABASE_URL`.
- Basic offline API tests.

## Not yet implemented
Live eBay search requires developer credentials. Affiliate revenue requires eBay Partner Network approval and a campaign ID. Scheduled price tracking, semantic AI matching, travel/jobs/learning providers, payments, subscriptions, email notifications and a native app are not included yet. Saved searches are stored but are not polled on a schedule.

## Local setup (Python 3.11+)
1. Create a Telegram bot with `@BotFather`.
2. Copy `.env.example` to `.env`; set `TELEGRAM_BOT_TOKEN`.
3. Add eBay developer credentials to enable live product search.
4. Install and run:

```bash
python -m venv .venv
# Windows PowerShell: .venv\\Scripts\\Activate.ps1
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

In a second terminal run `python -m app.bot`. Run tests with `python -m pytest -q`.

Open `http://localhost:8000`. To use the dashboard inside Telegram, deploy behind HTTPS, set `TELEGRAM_WEBAPP_URL`, configure the Mini App URL in `@BotFather`, then open it from the bot's button.

## eBay
Uses OAuth client credentials and `GET /buy/browse/v1/item_summary/search`. Production API access may be limited by marketplace and developer approval. For commissions, join eBay Partner Network and configure an approved campaign ID; normal item URLs do not automatically earn commission.

## Production checklist
Use HTTPS, PostgreSQL, migrations, backups, rate limits, monitoring, privacy policy, user data export/deletion and short-lived server sessions after Telegram login. Keep `.env` private. Respect provider terms and quotas. Never auto-purchase or apply for jobs without explicit confirmation.


## Social media publishing queue (v1.1)
A minimal scheduled publishing queue is included for Facebook Pages and Instagram Professional accounts.
- `POST /api/social/posts` queues a post with platform, text, optional public media URL and timezone-aware scheduled time.
- `GET /api/social/posts` lists queued posts.
- Run `python -m app.social_worker` in a separate process to publish due posts.
- Configure `META_ACCESS_TOKEN`, `META_PAGE_ID`, `META_IG_USER_ID`, and `META_GRAPH_VERSION`.

Meta prerequisites: Instagram Professional account connected to a Facebook Page, Meta developer app, required permissions, access token and any applicable review/approval. Instagram media must be publicly reachable. This prototype supports basic image posts and Facebook text/photo posts; not Reels, Stories, carousels, inbox automation or comments.

TikTok direct posting is not enabled: TikTok requires an approved developer app, user authorization and `video.publish` scope; unaudited apps have private-only visibility restrictions and creator consent UX requirements. YouTube requires Google OAuth and quota; X has separate API access requirements.

This worker is a single-instance prototype without production-grade atomic job claiming, retries, idempotency or dead-letter handling. Do not run multiple replicas with SQLite. Add those controls before public launch.


## PULSE Autopilot v1.2: content factory and command center
New capabilities:
- `/autopilot`: Telegram Mini App command-center UI.
- `POST /api/content/generate`: generates platform-specific copy in EN/ES/PT/FR/DE. Uses OpenAI Chat Completions if `OPENAI_API_KEY` is configured; otherwise uses deterministic no-cost templates.
- Automatic sensitive-topic classifier. Flagged content remains `pending_review`; ordinary content is `ready`.
- For ordinary Facebook/Instagram content, when `PUBLIC_BASE_URL` is HTTPS, the service creates a branded SVG asset and automatically queues the post for Meta publishing.
- `GET /api/content/calendar`: editorial calendar.
- `POST /api/content/{id}/approve`: approves sensitive content and queues it for Meta if its public asset URL is configured.
- `GET /api/analytics/overview`: content, publishing, referral and recorded revenue metrics.
- `POST /api/growth/track`: public referral event tracking (visit/signup/activation/purchase).
- `POST /api/revenue/events`: authenticated revenue ledger event; use verified payment/affiliate webhooks in production, never client-submitted amounts.
- `/media/<filename>` serves generated branded JPEG creative (with SVG helper retained for local testing).

## Run Autopilot
Set `PUBLIC_BASE_URL` to the HTTPS domain that serves PULSE. Set `META_ACCESS_TOKEN`, `META_PAGE_ID`, and `META_IG_USER_ID` after creating and authorizing a Meta developer app. Run the API and, separately, `python -m app.social_worker`. Open `/autopilot` inside the Telegram Mini App. Without OpenAI credentials the factory uses zero-cost templates; with an API key, text generation incurs usage charges.

## Channels and account setup
This release publishes Facebook Page and Instagram Professional image posts through the Meta Graph API adapter. TikTok, YouTube, X, LinkedIn, Pinterest and Telegram channel publishing are represented in the content calendar but need each platform's OAuth app, review and publishing adapter before automatic distribution. PULSE cannot silently create social accounts or accept platform terms for the owner: create the brand profiles, enable MFA, and authorize the integrations yourself. Do not share access tokens in chat.

## Safety and operational limitations
Sensitive topics are held for human review. The classifier is a heuristic, not a complete safety filter; review policy and moderation before public launch. The generated artwork is a branded typographic JPEG, not a generated photo or video. The current social worker is a single-instance prototype; use PostgreSQL, migrations, atomic job claims, retries/backoff, idempotency, rate limits, secrets management, audit logs and monitoring before scaling. Revenue is not automatic until affiliate networks/payment processors are connected and send verified events. No income is guaranteed.


## Docker Compose (API + publisher worker)
Copy `.env.example` to `.env`, fill the Meta credentials and set `PUBLIC_BASE_URL` to your HTTPS domain, then run:
```bash
docker compose up --build -d
docker compose logs -f api social-worker telegram-bot
```
The API and worker share a persistent SQLite volume for a low-cost single-host deployment. Do not scale the worker horizontally or use SQLite for multi-instance production; migrate to PostgreSQL and atomic job claiming first. Set a reverse proxy/TLS in front of port 8000. Never expose the API directly without HTTPS, authentication and rate limiting.


## PULSE v2 additions

- Global publishing pause (`GET /api/control/status`, `PUT /api/control/pause`). The social worker checks the persisted pause flag before claiming and before publishing queued work.
- Integration readiness report distinguishes configured Meta connections from publishers that are not implemented.
- Lead capture (`POST /api/leads`) with normalized-email deduplication; authenticated lead listing (`GET /api/leads`). Add consent language and a privacy notice to any public-facing capture form before production use.
- Failed Meta post retry (`POST /api/social/posts/{id}/retry`).
- Dashboard includes a global pause/resume control and integration readiness.

The lead endpoint is a minimal capture primitive, not a full CRM or mailing-list consent system. Payment processing, verified affiliate attribution, and non-Meta social publishing remain unimplemented.

On SQLite upgrades, startup applies a narrow compatibility migration for the lead-consent timestamp. Back up the database before upgrading any live deployment. For production-grade schema evolution, move to Alembic migrations and PostgreSQL.

## Version

PULSE AUTOPILOT 2.0.0 — operational control, lead capture with explicit consent, lead inbox, Meta retry endpoint, and integration readiness reporting.
