from fastapi.testclient import TestClient
from app.main import app
client=TestClient(app)
def test_health():
    r=client.get('/api/health'); assert r.status_code==200 and r.json()['status']=='ok'
def test_auth_required(): assert client.get('/api/me').status_code==401
def test_no_trust_in_arbitrary_header(): assert client.get('/api/me',headers={'X-Pulse-Telegram-Id':'123'}).status_code==401
def test_home():
    r=client.get('/'); assert r.status_code==200 and 'PULSE' in r.text


def test_social_queue_requires_auth():
    r=client.post("/api/social/posts",json={"platform":"facebook","text":"Hello PULSE","scheduled_at":"2026-11-12T12:00:00Z"})
    assert r.status_code==401


def test_health_has_autopilot_version():
    assert client.get("/api/health").json()["status"]=="ok"

def test_autopilot_dashboard_served():
    r=client.get("/autopilot")
    assert r.status_code==200 and "Content factory" in r.text

def test_content_factory_flags_sensitive_topics():
    from app.content_factory import requires_review
    assert requires_review("election analysis", "A neutral overview")
    assert not requires_review("home office desk setup", "Compare practical desk accessories")

def test_social_asset_is_valid_svg():
    from app.assets import make_social_svg, ASSET_DIR
    name=make_social_svg("A useful perspective", "Practical ideas", "en")
    data=(ASSET_DIR/name).read_text(encoding="utf-8")
    assert data.startswith("<svg") and "PULSE" in data


def test_content_generation_requires_auth():
    r=client.post("/api/content/generate",json={"topic":"useful productivity apps","platforms":["facebook"],"language":"en"})
    assert r.status_code==401

def test_analytics_requires_auth():
    assert client.get("/api/analytics/overview").status_code==401

def test_growth_tracking_is_public_and_records_event():
    r=client.post("/api/growth/track",json={"code":"PULSETEST","event_type":"visit","source":"test"})
    assert r.status_code==200 and r.json()["tracked"] is True


def test_authenticated_content_generation_and_sensitive_review():
    from app.db import SessionLocal
    from app.models import User
    with SessionLocal() as db:
        user=db.query(User).filter_by(telegram_id=918273646).first()
        if not user:
            user=User(telegram_id=918273646,username="pulse_review_test",language="en")
            db.add(user);db.commit()
    headers={"X-Pulse-Telegram-Id":"918273646"}
    r=client.post("/api/content/generate",headers=headers,
        json={"topic":"election information and voting","platforms":["facebook"],"language":"en"})
    assert r.status_code==200
    item=r.json()["items"][0]
    assert item["sensitive"] is True and item["status"]=="pending_review"
    blocked=client.post(f"/api/content/{item['id']}/queue",headers=headers)
    assert blocked.status_code==409
    approved=client.post(f"/api/content/{item['id']}/approve",headers=headers)
    assert approved.status_code==200


def test_social_image_is_jpeg():
    from app.assets import make_social_image, ASSET_DIR
    from PIL import Image
    name=make_social_image("A useful perspective","Useful productivity tools","en")
    with Image.open(ASSET_DIR/name) as im:
        assert im.format=="JPEG" and im.size==(1080,1350)

def test_control_status_requires_auth():
    assert client.get('/api/control/status').status_code == 401

def test_public_lead_capture_and_deduplication():
    email='pulse-v2-test@example.com'
    a=client.post('/api/leads',json={'email':email,'source':'test','interest':'newsletter','consent':True})
    b=client.post('/api/leads',json={'email':email,'source':'test','interest':'newsletter','consent':True})
    assert a.status_code==200 and a.json()['captured'] is True
    assert b.status_code==200 and b.json()['duplicate'] is True

def test_global_pause_requires_auth():
    assert client.put('/api/control/pause',json={'paused':True}).status_code==401

def test_health_reports_v2():
    assert client.get('/api/health').json()['version']=='2.0.0'

def test_global_pause_can_be_toggled_by_authenticated_owner():
    from app.db import SessionLocal
    from app.models import User
    with SessionLocal() as db:
        user=db.query(User).filter_by(telegram_id=918273645).first()
        if not user:
            user=User(telegram_id=918273645,username='pulse_control_test',language='en')
            db.add(user);db.commit()
    h={'X-Pulse-Telegram-Id':'918273645'}
    paused=client.put('/api/control/pause',headers=h,json={'paused':True})
    assert paused.status_code==200 and paused.json()['global_pause'] is True
    assert client.get('/api/control/status',headers=h).json()['global_pause'] is True
    resumed=client.put('/api/control/pause',headers=h,json={'paused':False})
    assert resumed.status_code==200 and resumed.json()['global_pause'] is False

def test_lead_requires_explicit_consent():
    r=client.post('/api/leads',json={'email':'no-consent@example.com','consent':False})
    assert r.status_code==400
