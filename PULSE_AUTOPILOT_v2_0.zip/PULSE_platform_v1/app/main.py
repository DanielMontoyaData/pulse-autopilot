from datetime import datetime
from pathlib import Path
from fastapi import FastAPI, Depends, HTTPException, Header
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from sqlalchemy import select
from app.config import settings
from app.db import Base, engine, get_db, migrate_schema
from app.models import User, SavedSearch, Opportunity, SocialPost, ContentItem, ReferralEvent, RevenueEvent, ControlSetting, Lead
from app.telegram_auth import validate_telegram_init_data
from app.content_factory import generate_copy, requires_review, next_schedule
from app.assets import make_social_svg, make_social_image, ASSET_DIR
from app.providers import EbayBrowseProvider, ProviderNotConfigured
BASE=Path(__file__).resolve().parent.parent
app=FastAPI(title="PULSE Core API",version="2.0.0")
provider=EbayBrowseProvider(); Base.metadata.create_all(bind=engine); migrate_schema()
app.mount("/static",StaticFiles(directory=str(BASE/"web")),name="static")
app.mount("/media",StaticFiles(directory=str(ASSET_DIR)),name="media")
class AuthPayload(BaseModel): init_data:str=Field(min_length=1)
class SearchPayload(BaseModel): query:str=Field(min_length=2,max_length=200); category:str="shopping"
class WatchPayload(BaseModel): query:str=Field(min_length=3,max_length=300); category:str="shopping"
def current_user(authorization:str|None=Header(default=None), x_pulse_telegram_id:str|None=Header(default=None), db:Session=Depends(get_db)):
    # Production identity comes only from signed, fresh Telegram Mini App initData.
    if authorization and authorization.startswith("tma "):
        try:
            tg=validate_telegram_init_data(authorization[4:])
        except Exception as exc:
            raise HTTPException(401, str(exc))
        u=db.scalar(select(User).where(User.telegram_id==int(tg["id"])))
        if not u:
            u=User(telegram_id=int(tg["id"]),username=tg.get("username"),language=(tg.get("language_code") or "en")[:8])
            db.add(u)
        else:
            u.username=tg.get("username")
            u.language=(tg.get("language_code") or u.language or "en")[:8]
        db.commit()
        return u
    # Local-only test identity. Never enable this mode on a public production deployment.
    if settings.environment=="development" and x_pulse_telegram_id and x_pulse_telegram_id.isdigit():
        u=db.scalar(select(User).where(User.telegram_id==int(x_pulse_telegram_id)))
        if u:return u
    raise HTTPException(401,"Authenticate with Telegram Mini App")
@app.get("/api/health")
def health(): return {"status":"ok","service":"pulse-core","version":"2.0.0"}

def _publishing_paused(db: Session) -> bool:
    row=db.get(ControlSetting,"global_pause")
    return bool(row and row.value.lower()=="true")

@app.get("/api/control/status")
def control_status(user: User=Depends(current_user),db: Session=Depends(get_db)):
    return {"global_pause":_publishing_paused(db),"publishing_enabled":not _publishing_paused(db),
            "meta_facebook_configured":meta_ready("facebook"),"meta_instagram_configured":meta_ready("instagram"),
            "openai_configured":bool(settings.openai_api_key),"public_https_configured":settings.public_base_url.startswith("https://"),
            "external_publishers":{"facebook":"meta" if meta_ready("facebook") else "not_configured",
             "instagram":"meta" if meta_ready("instagram") else "not_configured",
             "tiktok":"not_implemented","youtube":"not_implemented","x":"not_implemented",
             "linkedin":"not_implemented","pinterest":"not_implemented","telegram":"not_implemented"}}

class PausePayload(BaseModel): paused: bool
@app.put("/api/control/pause")
def set_global_pause(payload: PausePayload,user: User=Depends(current_user),db: Session=Depends(get_db)):
    row=db.get(ControlSetting,"global_pause")
    if not row: row=ControlSetting(key="global_pause",value=str(payload.paused).lower());db.add(row)
    else: row.value=str(payload.paused).lower()
    db.commit()
    return {"global_pause":payload.paused,"message":"Publishing paused" if payload.paused else "Publishing resumed"}

@app.post("/api/auth/telegram")
def login(p:AuthPayload,db:Session=Depends(get_db)):
    try: tg=validate_telegram_init_data(p.init_data)
    except Exception as e: raise HTTPException(401,str(e))
    u=db.scalar(select(User).where(User.telegram_id==int(tg["id"])))
    if not u: u=User(telegram_id=int(tg["id"]),username=tg.get("username"),language=(tg.get("language_code") or "en")[:8]); db.add(u)
    else: u.username=tg.get("username"); u.language=(tg.get("language_code") or u.language or "en")[:8]
    db.commit(); return {"ok":True,"user":{"telegram_id":u.telegram_id,"username":u.username,"language":u.language}}
@app.get("/api/me")
def me(user:User=Depends(current_user)): return {"telegram_id":user.telegram_id,"username":user.username,"language":user.language}
@app.post("/api/search/products")
async def search_products(p:SearchPayload,user:User=Depends(current_user),db:Session=Depends(get_db)):
    if p.category!="shopping": raise HTTPException(400,"This live provider currently supports shopping only")
    try: results=await provider.search(p.query)
    except ProviderNotConfigured: raise HTTPException(503,"eBay provider is not configured. Add developer credentials.")
    except Exception: raise HTTPException(502,"Product provider temporarily unavailable")
    for x in results:
        if not x["external_id"] or not x["url"]: continue
        old=db.scalar(select(Opportunity).where(Opportunity.external_id==x["external_id"]))
        if not old: db.add(Opportunity(provider=x["provider"],external_id=x["external_id"],title=x["title"],description=x["description"],url=x["url"],image_url=x["image_url"],price_value=x["price_value"],currency=x["currency"],category=x["category"],affiliate=x["affiliate"]))
    db.commit(); return {"query":p.query,"count":len(results),"results":results,"notice":"Prices and availability can change; verify with seller."}
@app.post("/api/watches")
def add_watch(p:WatchPayload,user:User=Depends(current_user),db:Session=Depends(get_db)):
    w=SavedSearch(user_id=user.id,query=p.query,category=p.category);db.add(w);db.commit();db.refresh(w);return {"id":w.id,"query":w.query,"category":w.category}
@app.get("/api/watches")
def watches(user:User=Depends(current_user),db:Session=Depends(get_db)):
    rows=db.scalars(select(SavedSearch).where(SavedSearch.user_id==user.id,SavedSearch.active==True)).all();return [{"id":x.id,"query":x.query,"category":x.category} for x in rows]
@app.get("/")
def home(): return FileResponse(BASE/"web"/"index.html")


class SocialPostPayload(BaseModel):
    platform: str = Field(pattern="^(instagram|facebook)$")
    text: str = Field(min_length=1, max_length=2200)
    media_url: str | None = None
    scheduled_at: datetime

@app.post("/api/social/posts")
def queue_social_post(payload: SocialPostPayload, user: User = Depends(current_user), db: Session = Depends(get_db)):
    if payload.platform == "instagram" and not payload.media_url:
        raise HTTPException(400, "Instagram publishing requires a publicly accessible image URL.")
    if not meta_ready(payload.platform):
        raise HTTPException(409, "Meta publishing credentials are not configured for this platform.")
    if payload.scheduled_at.tzinfo is None:
        raise HTTPException(400, "scheduled_at must include a timezone.")
    post = SocialPost(user_id=user.id, platform=payload.platform, text=payload.text,
                      media_url=payload.media_url, scheduled_at=payload.scheduled_at, status="queued")
    db.add(post); db.commit(); db.refresh(post)
    return {"id": post.id, "platform": post.platform, "status": post.status, "scheduled_at": post.scheduled_at.isoformat()}

@app.get("/api/social/posts")
def list_social_posts(user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.scalars(select(SocialPost).where(SocialPost.user_id==user.id).order_by(SocialPost.scheduled_at.desc()).limit(100)).all()
    return [{"id":p.id,"platform":p.platform,"text":p.text,"media_url":p.media_url,
             "scheduled_at":p.scheduled_at.isoformat(),"status":p.status,"last_error":p.last_error} for p in rows]


# --- PULSE Autopilot: content factory, calendar, growth and revenue analytics ---
ALLOWED_PLATFORMS = {"instagram","facebook","tiktok","youtube","x","linkedin","pinterest","telegram"}

def meta_ready(platform: str) -> bool:
    if not settings.meta_access_token: return False
    return bool(settings.meta_ig_user_id) if platform=="instagram" else bool(settings.meta_page_id)

class ContentGeneratePayload(BaseModel):
    topic: str = Field(min_length=3,max_length=300)
    platforms: list[str] = Field(min_length=1,max_length=7)
    language: str = Field(default="en",pattern="^(en|es|pt|fr|de)$")
    start_at: datetime | None = None

@app.post("/api/content/generate")
async def generate_content(payload: ContentGeneratePayload, user: User=Depends(current_user), db: Session=Depends(get_db)):
    platforms=list(dict.fromkeys(payload.platforms))
    if any(p not in ALLOWED_PLATFORMS for p in platforms):
        raise HTTPException(400,"Unsupported platform")
    created=[]
    for i,platform in enumerate(platforms):
        try:
            (title,body,hashtags),engine=await generate_copy(payload.topic,platform,payload.language)
        except Exception as exc:
            raise HTTPException(502,f"Content generation provider failed: {str(exc)[:180]}")
        sensitive=requires_review(payload.topic,body)
        scheduled=payload.start_at or next_schedule(i)
        if scheduled.tzinfo is None: raise HTTPException(400,"start_at must include timezone")
        media_url=None
        if platform in ("instagram","facebook"):
            filename=make_social_image(title,payload.topic,payload.language)
            media_url=f"{settings.public_base_url.rstrip('/')}/media/{filename}"
        item=ContentItem(user_id=user.id,topic=payload.topic,platform=platform,language=payload.language,
                         title=title,body=body,hashtags=hashtags,media_url=media_url,scheduled_at=scheduled,
                         status="pending_review" if sensitive else "ready",sensitive=sensitive)
        db.add(item);db.flush()
        # Auto-queue ordinary Meta content when a public URL is configured.
        if not sensitive and platform in ("facebook","instagram") and settings.public_base_url.startswith("https://") and meta_ready(platform) and not _publishing_paused(db):
            social=SocialPost(user_id=user.id,platform=platform,text=(body+"\\n\\n"+hashtags).strip(),
                              media_url=media_url,scheduled_at=scheduled,status="queued")
            db.add(social);db.flush();item.social_post_id=social.id;item.status="queued"
        elif not sensitive and platform not in ("facebook","instagram"):
            item.status="provider_required"
        created.append({"id":item.id,"platform":platform,"title":title,"body":body,"hashtags":hashtags,
                        "media_url":media_url,"scheduled_at":scheduled.isoformat(),"status":item.status,"sensitive":sensitive,"engine":engine})
    db.commit()
    return {"created":len(created),"items":created,"note":"Ordinary content is ready for scheduled publishing; sensitive content requires approval."}

@app.get("/api/content/calendar")
def content_calendar(start: datetime | None=None,end: datetime | None=None,user: User=Depends(current_user),db: Session=Depends(get_db)):
    q=select(ContentItem).where(ContentItem.user_id==user.id).order_by(ContentItem.scheduled_at)
    if start: q=q.where(ContentItem.scheduled_at>=start)
    if end: q=q.where(ContentItem.scheduled_at<=end)
    rows=db.scalars(q.limit(250)).all()
    return [{"id":x.id,"topic":x.topic,"platform":x.platform,"language":x.language,"title":x.title,
             "body":x.body,"hashtags":x.hashtags,"media_url":x.media_url,"scheduled_at":x.scheduled_at.isoformat(),
             "status":x.status,"sensitive":x.sensitive} for x in rows]

@app.post("/api/content/{content_id}/approve")
def approve_content(content_id:int,user:User=Depends(current_user),db:Session=Depends(get_db)):
    item=db.scalar(select(ContentItem).where(ContentItem.id==content_id,ContentItem.user_id==user.id))
    if not item: raise HTTPException(404,"Content not found")
    item.status="ready"
    if item.platform in ("facebook","instagram") and item.media_url and settings.public_base_url.startswith("https://") and meta_ready(item.platform) and not _publishing_paused(db):
        social=SocialPost(user_id=user.id,platform=item.platform,text=(item.body+"\\n\\n"+item.hashtags).strip(),
                          media_url=item.media_url,scheduled_at=item.scheduled_at,status="queued")
        db.add(social);db.flush();item.social_post_id=social.id;item.status="queued"
    db.commit()
    return {"id":item.id,"status":item.status}

@app.post("/api/content/{content_id}/queue")
def queue_content(content_id:int,user:User=Depends(current_user),db:Session=Depends(get_db)):
    item=db.scalar(select(ContentItem).where(ContentItem.id==content_id,ContentItem.user_id==user.id))
    if not item: raise HTTPException(404,"Content not found")
    if item.sensitive and item.status!="ready": raise HTTPException(409,"Sensitive content must be approved first")
    if item.status not in ("ready","failed"): raise HTTPException(409,f"Content status is {item.status}")
    if item.platform not in ("facebook","instagram"):
        item.status="provider_required";db.commit()
        return {"id":item.id,"status":item.status,"detail":"Platform OAuth/publishing adapter is not configured yet."}
    if item.platform=="instagram" and not item.media_url: raise HTTPException(400,"Instagram requires a public media asset")
    if item.platform in ("facebook","instagram") and not meta_ready(item.platform):
        item.status="integration_required";db.commit()
        return {"id":item.id,"status":item.status,"detail":"Configure the Meta access token and platform account ID before queueing."}
    social=SocialPost(user_id=user.id,platform=item.platform,text=(item.body+"\\n\\n"+item.hashtags).strip(),
                      scheduled_at=item.scheduled_at,media_url=item.media_url,status="queued")
    db.add(social);db.flush();item.social_post_id=social.id;item.status="queued";db.commit()
    return {"id":item.id,"social_post_id":social.id,"status":item.status}

@app.get("/api/analytics/overview")
def analytics_overview(user:User=Depends(current_user),db:Session=Depends(get_db)):
    content=db.scalars(select(ContentItem).where(ContentItem.user_id==user.id)).all()
    posts=db.scalars(select(SocialPost).where(SocialPost.user_id==user.id)).all()
    rev=db.scalars(select(RevenueEvent).where(RevenueEvent.user_id==user.id)).all()
    referrals=db.scalars(select(ReferralEvent).where(ReferralEvent.user_id==user.id)).all()
    total=sum(x.amount for x in rev)
    return {"content_total":len(content),"content_ready":sum(x.status=="ready" for x in content),
            "content_review":sum(x.status=="pending_review" for x in content),
            "posts_queued":sum(x.status=="queued" for x in posts),
            "posts_published":sum(x.status=="published" for x in posts),
            "posts_failed":sum(x.status=="failed" for x in posts),
            "referral_events":len(referrals),"revenue_total":round(total,2),
            "revenue_currency":rev[0].currency if rev else "USD",
            "revenue_events":len(rev)}

class ReferralPayload(BaseModel):
    code: str = Field(min_length=2,max_length=64)
    event_type: str = Field(default="visit",pattern="^(visit|signup|activation|purchase)$")
    source: str = Field(default="unknown",max_length=64)

@app.post("/api/growth/track")
def track_growth(payload:ReferralPayload,db:Session=Depends(get_db)):
    db.add(ReferralEvent(code=payload.code,event_type=payload.event_type,source=payload.source))
    db.commit()
    return {"tracked":True}

class RevenuePayload(BaseModel):
    source: str = Field(min_length=2,max_length=64)
    event_type: str = Field(default="commission",pattern="^(commission|subscription|sale|refund)$")
    amount: float = Field(ge=0)
    currency: str = Field(default="USD",min_length=3,max_length=8)
    external_id: str | None = None

@app.post("/api/revenue/events")
def record_revenue(payload:RevenuePayload,user:User=Depends(current_user),db:Session=Depends(get_db)):
    if payload.external_id and db.scalar(select(RevenueEvent).where(RevenueEvent.external_id==payload.external_id)):
        return {"recorded":False,"duplicate":True}
    event=RevenueEvent(user_id=user.id,source=payload.source,event_type=payload.event_type,
                       amount=payload.amount,currency=payload.currency,external_id=payload.external_id)
    db.add(event);db.commit()
    return {"recorded":True,"id":event.id}

class LeadPayload(BaseModel):
    name: str | None = Field(default=None,max_length=160)
    email: str = Field(min_length=5,max_length=254)
    source: str = Field(default="organic",max_length=80)
    interest: str = Field(default="general",max_length=160)
    consent: bool

@app.post("/api/leads")
def capture_lead(payload: LeadPayload, db: Session=Depends(get_db)):
    email=payload.email.strip().lower()
    if not payload.consent: raise HTTPException(400,"Explicit data-processing consent is required")
    if "@" not in email or email.startswith("@") or email.endswith("@"):
        raise HTTPException(400,"A valid email is required")
    existing=db.scalar(select(Lead).where(Lead.email==email,Lead.status!="archived"))
    if existing: return {"captured":False,"duplicate":True,"id":existing.id}
    lead=Lead(name=payload.name,email=email,source=payload.source,interest=payload.interest)
    db.add(lead);db.commit();db.refresh(lead)
    return {"captured":True,"id":lead.id}

@app.get("/api/leads")
def list_leads(user: User=Depends(current_user),db: Session=Depends(get_db)):
    rows=db.scalars(select(Lead).order_by(Lead.created_at.desc()).limit(200)).all()
    return [{"id":x.id,"name":x.name,"email":x.email,"source":x.source,"interest":x.interest,"status":x.status,"created_at":x.created_at.isoformat()} for x in rows]

@app.post("/api/social/posts/{post_id}/retry")
def retry_social_post(post_id:int,user:User=Depends(current_user),db:Session=Depends(get_db)):
    post=db.scalar(select(SocialPost).where(SocialPost.id==post_id,SocialPost.user_id==user.id))
    if not post: raise HTTPException(404,"Post not found")
    if post.status not in ("failed","queued"): raise HTTPException(409,"Only failed or queued posts can be retried")
    if not meta_ready(post.platform): raise HTTPException(409,"Platform credentials are not configured")
    post.status="queued";post.last_error=None;db.commit()
    return {"id":post.id,"status":post.status}

@app.get("/api/dashboard")
def dashboard(user:User=Depends(current_user),db:Session=Depends(get_db)):
    return {"user":{"username":user.username,"language":user.language},"analytics":analytics_overview(user,db),
            "calendar":content_calendar(None,None,user,db)[:20]}

@app.get("/autopilot")
def autopilot_home(): return FileResponse(BASE/"web"/"autopilot.html")
