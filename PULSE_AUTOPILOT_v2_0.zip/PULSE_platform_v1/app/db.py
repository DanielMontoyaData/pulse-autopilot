from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase
from app.config import settings
args = {"check_same_thread": False} if settings.database_url.startswith("sqlite") else {}
engine = create_engine(settings.database_url, connect_args=args, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
class Base(DeclarativeBase): pass
def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()


def migrate_schema():
    """Small forward-only SQLite compatibility migration for the v1.2 -> v2 lead table."""
    if engine.dialect.name != "sqlite":
        return
    from sqlalchemy import inspect, text
    inspector=inspect(engine)
    if "leads" in inspector.get_table_names():
        columns={c["name"] for c in inspector.get_columns("leads")}
        if "consent_at" not in columns:
            with engine.begin() as conn:
                conn.execute(text("ALTER TABLE leads ADD COLUMN consent_at DATETIME"))
