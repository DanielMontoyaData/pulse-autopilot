import logging
from telegram import Update,InlineKeyboardButton,InlineKeyboardMarkup,WebAppInfo
from telegram.ext import Application,CommandHandler,ContextTypes
from sqlalchemy import select
from app.config import settings
from app.db import Base,engine,SessionLocal
from app.models import User,SavedSearch
from app.providers import EbayBrowseProvider,ProviderNotConfigured
from app.i18n import t
logging.basicConfig(level=logging.INFO);log=logging.getLogger("pulse-bot");provider=EbayBrowseProvider()
async def start(update:Update,context:ContextTypes.DEFAULT_TYPE):
    tg=update.effective_user
    with SessionLocal() as db:
        u=db.scalar(select(User).where(User.telegram_id==tg.id))
        if not u:u=User(telegram_id=tg.id,username=tg.username,language=(tg.language_code or "en")[:8]);db.add(u)
        else:u.username=tg.username
        db.commit();lang=u.language if u.language in ("en","es") else "en"
    kb=[[InlineKeyboardButton("Open PULSE dashboard",web_app=WebAppInfo(url=settings.telegram_webapp_url))]] if settings.telegram_webapp_url else None
    await update.message.reply_text(t(lang,"welcome"),parse_mode="Markdown",reply_markup=InlineKeyboardMarkup(kb) if kb else None)
async def search_cmd(update:Update,context:ContextTypes.DEFAULT_TYPE):
    q=" ".join(context.args).strip()
    if len(q)<2:await update.message.reply_text("Usage: /search noise cancelling headphones");return
    await update.message.reply_text("🔎 Searching live listings…")
    try: rows=await provider.search(q,5)
    except ProviderNotConfigured:await update.message.reply_text("Live search needs eBay developer credentials on the server.");return
    except Exception:log.exception("eBay search failed");await update.message.reply_text("Provider unavailable. Try later.");return
    if not rows:await update.message.reply_text("No results. Try a broader query.");return
    for x in rows:
        price=f"{x['price_value']} {x['currency']}" if x.get("price_value") else "Price unavailable"
        await update.message.reply_text(f"🛍 *{x['title']}*\n{price}\n{x['url']}\n\nVerify price and availability with seller.",parse_mode="Markdown")
async def watch_cmd(update:Update,context:ContextTypes.DEFAULT_TYPE):
    q=" ".join(context.args).strip()
    if len(q)<3:await update.message.reply_text("Usage: /watch a refurbished phone under $300");return
    tg=update.effective_user
    with SessionLocal() as db:
        u=db.scalar(select(User).where(User.telegram_id==tg.id))
        if not u:u=User(telegram_id=tg.id,username=tg.username,language=(tg.language_code or "en")[:8]);db.add(u);db.commit();db.refresh(u)
        db.add(SavedSearch(user_id=u.id,query=q,category="shopping"));db.commit()
    await update.message.reply_text("✅ Search saved. Scheduled price monitoring is not active in this release.")
async def my_cmd(update:Update,context:ContextTypes.DEFAULT_TYPE):
    tg=update.effective_user
    with SessionLocal() as db:
        u=db.scalar(select(User).where(User.telegram_id==tg.id));rows=db.scalars(select(SavedSearch).where(SavedSearch.user_id==u.id,SavedSearch.active==True)).all() if u else []
    await update.message.reply_text("\n".join(f"{r.id}. {r.query}" for r in rows) if rows else "No saved searches. Use /watch.")
async def language_cmd(update:Update,context:ContextTypes.DEFAULT_TYPE):
    lang=context.args[0].lower() if context.args else ""
    if lang not in ("en","es"):await update.message.reply_text("Usage: /language en or /language es");return
    tg=update.effective_user
    with SessionLocal() as db:
        u=db.scalar(select(User).where(User.telegram_id==tg.id))
        if not u:u=User(telegram_id=tg.id,username=tg.username);db.add(u)
        u.language=lang;db.commit()
    await update.message.reply_text("Language updated.")
async def help_cmd(update:Update,context:ContextTypes.DEFAULT_TYPE):
    tg=update.effective_user
    with SessionLocal() as db:u=db.scalar(select(User).where(User.telegram_id==tg.id));lang=u.language if u and u.language in ("en","es") else "en"
    await update.message.reply_text(t(lang,"help"))
def main():
    if not settings.telegram_bot_token:raise SystemExit("Set TELEGRAM_BOT_TOKEN before starting bot")
    Base.metadata.create_all(bind=engine);app=Application.builder().token(settings.telegram_bot_token).build()
    for name,fn in [("start",start),("search",search_cmd),("watch",watch_cmd),("my",my_cmd),("language",language_cmd),("help",help_cmd)]:app.add_handler(CommandHandler(name,fn))
    app.run_polling()
if __name__=="__main__":main()
