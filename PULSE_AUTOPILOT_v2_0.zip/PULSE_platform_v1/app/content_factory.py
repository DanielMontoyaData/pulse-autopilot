import re, httpx
from datetime import datetime, timedelta, timezone
from app.config import settings

SENSITIVE_TERMS = re.compile(r"\b(election|vote|voting|politic|political|medical|diagnos|prescription|suicide|self-harm|weapon|violence|breaking news|emergency|crisis|investment advice|guaranteed returns)\b", re.I)

def requires_review(topic: str, body: str) -> bool:
    return bool(SENSITIVE_TERMS.search(topic + " " + body))

def fallback_copy(topic: str, platform: str, language: str):
    if language.startswith("es"):
        title=f"Una idea útil sobre {topic}"
        body=(f"¿Has considerado {topic}? En PULSE estamos explorando herramientas e ideas que ayudan a tomar mejores decisiones. "
              "Compara opciones, verifica las fuentes y elige lo que realmente te aporte valor. "
              "Guarda esta publicación y descubre PULSE.")
        tags="#PULSE #IdeasÚtiles #Descubre"
    else:
        title=f"A useful perspective on {topic}"
        body=(f"Have you explored {topic}? At PULSE, we're discovering tools and ideas that help people make better decisions. "
              "Compare options, verify sources, and choose what genuinely adds value. Save this post and discover PULSE.")
        tags="#PULSE #UsefulIdeas #Discover"
    if platform in ("x",): body=body[:240]
    return title, body, tags

async def generate_copy(topic: str, platform: str, language: str):
    if not settings.openai_api_key:
        return fallback_copy(topic, platform, language), "template"
    prompt=("Create one original, factual social post. Avoid invented statistics, unsupported claims, spam, engagement bait, "
            "and promises. Return JSON with title, body, hashtags. Adapt length and tone to platform. "
            f"Language: {language}. Platform: {platform}. Topic: {topic}.")
    async with httpx.AsyncClient(timeout=40) as client:
        r=await client.post("https://api.openai.com/v1/chat/completions",
            headers={"Authorization":f"Bearer {settings.openai_api_key}"},
            json={"model":settings.openai_model,"messages":[{"role":"user","content":prompt}],
                  "response_format":{"type":"json_object"}})
        r.raise_for_status()
        data=r.json()["choices"][0]["message"]["content"]
        import json
        obj=json.loads(data)
        return (obj["title"],obj["body"],obj.get("hashtags","")), "openai"

def next_schedule(index: int):
    # deterministic low-cost cadence: 10:00 and 18:00 UTC over coming days
    day=index//2
    hour=10 if index%2==0 else 18
    target=datetime.now(timezone.utc).replace(hour=hour,minute=0,second=0,microsecond=0)+timedelta(days=day)
    if target <= datetime.now(timezone.utc): target += timedelta(days=1)
    return target
