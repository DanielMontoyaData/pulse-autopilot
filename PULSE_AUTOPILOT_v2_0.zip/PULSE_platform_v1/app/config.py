from pydantic_settings import BaseSettings, SettingsConfigDict
class Settings(BaseSettings):
    environment: str = "development"
    database_url: str = "sqlite:///./pulse.db"
    telegram_bot_token: str = ""
    telegram_webapp_url: str = ""
    telegram_init_data_max_age_seconds: int = 86400
    ebay_client_id: str = ""
    ebay_client_secret: str = ""
    ebay_marketplace_id: str = "EBAY_US"
    ebay_environment: str = "production"
    ebay_campaign_id: str = ""
    openai_api_key: str = ""
    openai_model: str = "gpt-4.1-mini"
    pulse_admin_webhook_secret: str = ""
    meta_access_token: str = ""
    meta_page_id: str = ""
    meta_ig_user_id: str = ""
    meta_graph_version: str = "v23.0"
    public_base_url: str = "http://localhost:8000"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore", case_sensitive=False)
settings = Settings()
