import httpx
from app.config import settings

class MetaNotConfigured(Exception): pass

async def publish_meta_post(platform: str, text: str, media_url: str | None):
    if not settings.meta_access_token: raise MetaNotConfigured("META_ACCESS_TOKEN is missing")
    base=f"https://graph.facebook.com/{settings.meta_graph_version}"
    async with httpx.AsyncClient(timeout=45) as client:
        if platform == "facebook":
            if not settings.meta_page_id: raise MetaNotConfigured("META_PAGE_ID is missing")
            if media_url:
                endpoint=f"{base}/{settings.meta_page_id}/photos"
                data={"url":media_url,"caption":text,"access_token":settings.meta_access_token}
            else:
                endpoint=f"{base}/{settings.meta_page_id}/feed"
                data={"message":text,"access_token":settings.meta_access_token}
            response=await client.post(endpoint,data=data); response.raise_for_status()
            return str(response.json().get("post_id") or response.json().get("id"))
        if platform == "instagram":
            if not settings.meta_ig_user_id: raise MetaNotConfigured("META_IG_USER_ID is missing")
            if not media_url: raise ValueError("Instagram image publishing requires media_url")
            container=await client.post(f"{base}/{settings.meta_ig_user_id}/media",
                data={"image_url":media_url,"caption":text,"access_token":settings.meta_access_token})
            container.raise_for_status(); creation_id=container.json()["id"]
            publish=await client.post(f"{base}/{settings.meta_ig_user_id}/media_publish",
                data={"creation_id":creation_id,"access_token":settings.meta_access_token})
            publish.raise_for_status(); return str(publish.json().get("id"))
    raise ValueError("Unsupported Meta platform")
