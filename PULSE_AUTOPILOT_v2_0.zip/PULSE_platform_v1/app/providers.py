import base64, time, httpx
from app.config import settings
class ProviderNotConfigured(Exception): pass
class EbayBrowseProvider:
    def __init__(self): self._token=None; self._expiry=0
    @property
    def root(self): return "https://api.sandbox.ebay.com" if settings.ebay_environment == "sandbox" else "https://api.ebay.com"
    async def token(self):
        if not settings.ebay_client_id or not settings.ebay_client_secret: raise ProviderNotConfigured()
        if self._token and time.time() < self._expiry-60: return self._token
        basic=base64.b64encode(f"{settings.ebay_client_id}:{settings.ebay_client_secret}".encode()).decode()
        async with httpx.AsyncClient(timeout=20) as c:
            r=await c.post(self.root+"/identity/v1/oauth2/token",headers={"Authorization":"Basic "+basic,"Content-Type":"application/x-www-form-urlencoded"},data={"grant_type":"client_credentials","scope":"https://api.ebay.com/oauth/api_scope"})
            r.raise_for_status(); data=r.json()
        self._token=data["access_token"]; self._expiry=time.time()+int(data.get("expires_in",7200)); return self._token
    async def search(self, query, limit=10):
        token=await self.token(); headers={"Authorization":"Bearer "+token,"X-EBAY-C-MARKETPLACE-ID":settings.ebay_marketplace_id,"Accept":"application/json"}
        params={"q":query,"limit":min(max(limit,1),50)}
        if settings.ebay_campaign_id:
            headers["X-EBAY-C-ENDUSERCTX"] = f"affiliateCampaignId={settings.ebay_campaign_id}"
        async with httpx.AsyncClient(timeout=25) as c:
            r=await c.get(self.root+"/buy/browse/v1/item_summary/search",headers=headers,params=params); r.raise_for_status(); payload=r.json()
        out=[]
        for x in payload.get("itemSummaries",[]):
            p=x.get("price") or {}
            out.append({"provider":"ebay","external_id":x.get("itemId",""),"title":x.get("title","Untitled"),"description":x.get("shortDescription",""),"url":x.get("itemAffiliateWebUrl") or x.get("itemWebUrl",""),"image_url":(x.get("image") or {}).get("imageUrl"),"price_value":p.get("value"),"currency":p.get("currency"),"category":"shopping","affiliate":bool(x.get("itemAffiliateWebUrl"))})
        return out
