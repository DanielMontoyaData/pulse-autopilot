import asyncio, logging
from datetime import datetime, timezone
from sqlalchemy import select
from app.db import Base,engine,SessionLocal,migrate_schema
from app.models import SocialPost, ControlSetting
from app.meta_publisher import publish_meta_post
logging.basicConfig(level=logging.INFO); log=logging.getLogger("pulse-social-worker")
async def process_due_posts():
    now=datetime.now(timezone.utc)
    with SessionLocal() as db:
        pause=db.get(ControlSetting,"global_pause")
        if pause and pause.value.lower()=="true":
            return
        posts=db.scalars(select(SocialPost).where(SocialPost.status=="queued",SocialPost.scheduled_at<=now).order_by(SocialPost.scheduled_at).limit(10)).all()
        ids=[p.id for p in posts]
    for post_id in ids:
        with SessionLocal() as db:
            post=db.get(SocialPost,post_id)
            pause=db.get(ControlSetting,"global_pause")
            if pause and pause.value.lower()=="true": return
            if not post or post.status!="queued": continue
            post.status="processing"; db.commit(); platform,text,media=post.platform,post.text,post.media_url
        try:
            provider_id=await publish_meta_post(platform,text,media)
            with SessionLocal() as db:
                post=db.get(SocialPost,post_id)
                if post: post.status="published"; post.provider_post_id=provider_id; post.last_error=None; db.commit()
            log.info("Published post %s",post_id)
        except Exception as exc:
            with SessionLocal() as db:
                post=db.get(SocialPost,post_id)
                if post: post.status="failed"; post.last_error=str(exc)[:2000]; db.commit()
            log.exception("Publishing failed for post %s",post_id)
async def main():
    Base.metadata.create_all(bind=engine); migrate_schema()
    while True:
        await process_due_posts(); await asyncio.sleep(30)
if __name__=="__main__": asyncio.run(main())
