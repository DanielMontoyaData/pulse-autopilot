from pathlib import Path
from html import escape
import re, uuid

ASSET_DIR=Path(__file__).resolve().parent.parent/"generated_assets"
ASSET_DIR.mkdir(exist_ok=True)

def make_social_svg(title: str, topic: str, language: str="en") -> str:
    safe_title=escape(title[:70])
    safe_topic=escape(topic[:100])
    filename=f"pulse-{uuid.uuid4().hex}.svg"
    # Designed as a clean, branded typographic asset; no fabricated photography.
    svg=f"""<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1350" viewBox="0 0 1080 1350">
    <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#10172f"/><stop offset="1" stop-color="#40317f"/></linearGradient>
    <radialGradient id="r"><stop offset="0" stop-color="#8b7cff" stop-opacity=".45"/><stop offset="1" stop-color="#8b7cff" stop-opacity="0"/></radialGradient></defs>
    <rect width="1080" height="1350" fill="url(#g)"/><circle cx="850" cy="300" r="500" fill="url(#r)"/>
    <path d="M80 180H1000" stroke="#8b7cff" stroke-width="3" opacity=".8"/>
    <text x="80" y="130" fill="#c8c0ff" font-family="Arial,sans-serif" font-size="44" font-weight="700" letter-spacing="12">PULSE</text>
    <text x="80" y="520" fill="#ffffff" font-family="Arial,sans-serif" font-size="66" font-weight="700">{safe_title}</text>
    <foreignObject x="80" y="650" width="900" height="280"><div xmlns="http://www.w3.org/1999/xhtml" style="font:36px Arial,sans-serif;color:#d8def5;line-height:1.35">{safe_topic}</div></foreignObject>
    <path d="M80 1100H1000" stroke="#8b7cff" stroke-width="3" opacity=".8"/>
    <text x="80" y="1190" fill="#c8c0ff" font-family="Arial,sans-serif" font-size="30">DISCOVER · CREATE · GROW</text>
    <text x="80" y="1260" fill="#9ca8ca" font-family="Arial,sans-serif" font-size="24">pulse • Your opportunity engine</text></svg>"""
    (ASSET_DIR/filename).write_text(svg,encoding="utf-8")
    return filename


def make_social_image(title: str, topic: str, language: str="en") -> str:
    from PIL import Image, ImageDraw, ImageFont
    import textwrap
    filename=f"pulse-{uuid.uuid4().hex}.jpg"
    w,h=1080,1350
    im=Image.new("RGB",(w,h))
    px=im.load()
    for y in range(h):
        for x in range(w):
            t=(x/w+y/h)/2
            px[x,y]=(int(14+50*t),int(20+18*t),int(45+85*t))
    draw=ImageDraw.Draw(im)
    # Subtle geometric brand motif
    draw.ellipse((600,-180,1260,480),fill=(52,48,116))
    draw.ellipse((720,-60,1150,370),fill=(37,40,89))
    try:
        bold=ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",58)
        regular=ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",34)
        brand=ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",42)
    except OSError:
        bold=regular=brand=ImageFont.load_default()
    draw.text((78,90),"PULSE",font=brand,fill=(205,198,255))
    draw.line((80,170,1000,170),fill=(139,124,255),width=3)
    # Wrap long headlines and explanatory text to keep all text in safe bounds.
    title_lines=textwrap.wrap(title, width=24)[:4]
    y=390
    for line in title_lines:
        draw.text((80,y),line,font=bold,fill=(255,255,255),stroke_width=0)
        y+=82
    topic_lines=textwrap.wrap(topic,width=43)[:5]
    y=max(y+70,720)
    for line in topic_lines:
        draw.text((82,y),line,font=regular,fill=(218,225,245))
        y+=54
    draw.line((80,1120,1000,1120),fill=(139,124,255),width=3)
    draw.text((80,1170),"DISCOVER  ·  CREATE  ·  GROW",font=regular,fill=(205,198,255))
    draw.text((80,1260),"PULSE  |  Your opportunity engine",font=ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",22),fill=(165,177,205))
    im.save(ASSET_DIR/filename,"JPEG",quality=90,optimize=True)
    return filename
