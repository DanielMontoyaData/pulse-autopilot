import hashlib, hmac, json, time
from urllib.parse import parse_qsl
from app.config import settings
def validate_telegram_init_data(init_data: str):
    if not settings.telegram_bot_token: raise ValueError("Telegram bot token is not configured")
    pairs = dict(parse_qsl(init_data, keep_blank_values=True))
    received = pairs.pop("hash", None)
    if not received: raise ValueError("Missing Telegram initData hash")
    check = "\n".join(f"{k}={v}" for k,v in sorted(pairs.items()))
    secret = hmac.new(b"WebAppData", settings.telegram_bot_token.encode(), hashlib.sha256).digest()
    expected = hmac.new(secret, check.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, received): raise ValueError("Invalid Telegram initData signature")
    auth_date = int(pairs.get("auth_date", "0"))
    if auth_date <= 0 or time.time()-auth_date > settings.telegram_init_data_max_age_seconds or auth_date > time.time()+60:
        raise ValueError("Telegram initData expired")
    user = json.loads(pairs.get("user", "{}"))
    if not user.get("id"): raise ValueError("Telegram user missing")
    return user
